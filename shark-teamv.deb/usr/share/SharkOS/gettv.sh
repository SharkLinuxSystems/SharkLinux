wget -O teamv.tar.xz https://download.teamviewer.com/download/teamviewer_i386.tar.xz
tar -Jxvf teamv.tar.xz
rm teamv.tar.xz
rm gettv.sh
