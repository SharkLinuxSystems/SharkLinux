

#!/usr/bin/env bash

LXD_SOURCE_DIR=/var/lib/lxd/containers
LXD_MOUNT_DIR=/srv/lxd
USER_HOST_MOUNT=`id -u`
GROUP_HOST_MOUNT=`id -g`

