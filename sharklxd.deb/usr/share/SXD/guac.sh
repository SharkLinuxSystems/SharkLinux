cd /tmp
my_ip=$(ip route get 8.8.8.8 | awk '/8.8.8.8/ {print $NF}')
cat > new <<EOF
echo np | adduser ubuntu
echo "ubuntu:ubuntu" | chpasswd
adduser ubuntu sudo
EOF
chmod +x new
echo "Created user 'shark' "
sudo sh new > /dev/null 2>&1
cat> sshd_config <<EOF
Port 22
Protocol 2
# HostKeys for protocol version 2
HostKey /etc/ssh/ssh_host_rsa_key
HostKey /etc/ssh/ssh_host_dsa_key
HostKey /etc/ssh/ssh_host_ecdsa_key
HostKey /etc/ssh/ssh_host_ed25519_key
UsePrivilegeSeparation yes
KeyRegenerationInterval 3600
ServerKeyBits 1024
SyslogFacility AUTH
LogLevel INFO
LoginGraceTime 120
PermitRootLogin prohibit-password
StrictModes yes
RSAAuthentication yes
PubkeyAuthentication yes
IgnoreRhosts yes
RhostsRSAAuthentication no
HostbasedAuthentication no
PermitEmptyPasswords no
ChallengeResponseAuthentication no
PasswordAuthentication yes
X11Forwarding yes
X11DisplayOffset 10
PrintMotd no
PrintLastLog yes
TCPKeepAlive yes
AcceptEnv LANG LC_*
Subsystem sftp /usr/lib/openssh/sftp-server
UsePAM yes
EOF
rm /etc/ssh/sshd_config
mv sshd_config /etc/ssh/
apt-get install -y fail2ban build-essential htop libcairo2-dev libjpeg62-dev libpng12-dev libossp-uuid-dev tomcat7
apt-get install -y libfreerdp-dev libpango1.0-dev libssh2-1-dev nano libtelnet-dev libvncserver-dev libpulse-dev libssl-dev libvorbis-dev
cd ~
wget http://sourceforge.net/projects/guacamole/files/current/source/guacamole-server-0.9.9.tar.gz 
tar -xzf guacamole-server-0.9.9.tar.gz && cd guacamole-server-0.9.9/
./configure --with-init-dir=/etc/init.d && make && make install
ldconfig && update-rc.d guacd defaults
cd ~ && mkdir /etc/guacamole
cd /etc/guacamole
cat> guacamole.properties <<EOF
guacd-hostname: localhost
guacd-port: 4822
lib-directory: /var/lib/tomcat7/webapps/guacamole/WEB-INF/classes
auth-provider: net.sourceforge.guacamole.net.basic.BasicFileAuthenticationProvider
basic-user-mapping: /etc/guacamole/user-mapping.xml
EOF
mkdir /usr/share/tomcat7/.guacamole
ln -s /etc/guacamole/guacamole.properties /usr/share/tomcat7/.guacamole
wget http://sourceforge.net/projects/guacamole/files/current/binary/guacamole-0.9.9.war
cp guacamole-0.9.9.war /var/lib/tomcat7/webapps/guacamole.war
service guacd start && service tomcat7 restart
service tomcat7 stop
mv /var/lib/tomcat7/webapps/ROOT /var/lib/tomcat7/webapps/ROOT.bkp
mv /var/lib/tomcat7/webapps/guacamole /var/lib/tomcat7/webapps/ROOT
service tomcat7 start
cd /home/ubuntu
cat> sxd-cloud-panel <<EOF
firefox 'http://$my_ip:8080'
EOF
chmod 777 sxd-cloud-panel

