cite about-plugin
about-plugin 'load fzf, if you are using it'

[ -f ~/.fzf.bash ] && source ~/.fzf.bash
