
shark-install fail2ban build-essential htop libcairo2-dev libjpeg62-dev libpng12-dev libossp-uuid-dev tomcat7 xrdp
shark-install  libfreerdp-dev libpango1.0-dev libssh2-1-dev nano libtelnet-dev libvncserver-dev libpulse-dev libssl-dev libvorbis-dev
cd /tmp
wget http://sharklinux.net/guacamole-server-0.9.9.tar.gz 
tar -xzf guacamole-server-0.9.9.tar.gz && cd guacamole-server-0.9.9/
./configure --with-init-dir=/etc/init.d && make && make install
ldconfig && update-rc.d guacd defaults
cd ~ && mkdir /etc/guacamole
cd /etc/guacamole
cat> guacamole.properties <<EOF
guacd-hostname: localhost
guacd-port: 4822
lib-directory: /var/lib/tomcat7/webapps/guacamole/WEB-INF/classes
auth-provider: net.sourceforge.guacamole.net.basic.BasicFileAuthenticationProvider
basic-user-mapping: /etc/guacamole/user-mapping.xml
EOF
my_ip=$(ip route get 8.8.8.8 | awk '/8.8.8.8/ {print $NF}')
host=$(cat /etc/hostname)
cat> user-mapping.xml <<EOF
<user-mapping>
 <authorize username="admin" password="password">
<connection name=" $host RDP ">
    <protocol>rdp</protocol>
    <param name="hostname">$my_ip</param>
    <param name="port">3389</param>
</connection>
<connection name=" $host ssh">
    <protocol>ssh</protocol>
    <param name="hostname">$my_ip</param>
    <param name="port">22</param>
</connection>
</authorize>
</user-mapping>
EOF
cd /tmp
mkdir /usr/share/tomcat7/.guacamole
ln -s /etc/guacamole/guacamole.properties /usr/share/tomcat7/.guacamole
wget http://sharklinux.net/guacamole-0.9.9.war
cp guacamole-0.9.9.war /var/lib/tomcat7/webapps/guacamole.war
service guacd start && service tomcat7 restart
service tomcat7 stop
mv /var/lib/tomcat7/webapps/ROOT /var/lib/tomcat7/webapps/ROOT.bkp
mv /var/lib/tomcat7/webapps/guacamole /var/lib/tomcat7/webapps/ROOT
service tomcat7 start

