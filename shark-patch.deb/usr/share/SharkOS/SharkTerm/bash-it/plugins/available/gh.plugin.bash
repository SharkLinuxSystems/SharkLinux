cite about-plugin
about-plugin 'load gh, if you are using it (DEPRECATED, use hub instead)'

command -v gh 2> /dev/null && eval "$(gh alias -s)"
