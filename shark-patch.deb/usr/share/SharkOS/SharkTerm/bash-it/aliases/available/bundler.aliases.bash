cite 'about-alias'
about-alias 'ruby bundler'

# Bundler Commands
alias be='bundle exec'
alias bi='bundle install'
alias bl='bundle list'
alias bu='bundle update'
alias bp='bundle package'
